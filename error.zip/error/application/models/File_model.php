<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class File_model extends CI_Model {

	public function savefile($data)
	{
	  $filedata=array(
       'name'=>$data[1],
       'email'=>$data[2],
       'password'=>$data[3],
       'status'=>$data[4]
	  );	
	  $this->db->insert("register", $filedata);
	}
}
