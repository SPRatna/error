<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin | Dashboard</title>
	<link rel="stylesheet" href="<?php echo base_url();?>public/suraj/bootstrap.min.css">
	<script type="text/javascript" src="<?php echo base_url();?>public/suraj/jquery.min.css"></script>
	<script type="text/javascript" src="<?php echo base_url();?>public/suraj/popper.min.css"></script>	
	<script type="text/javascript" src="<?php echo base_url();?>public/suraj/bootstrap.min.css"></script>
</head>
<body>
	<div class="container-fluid">
	  <div class="jumbotron">
	  	<a href="<?php echo base_url().'admin/login/logout';?>" class="btn btn-outline-danger float-right mt-n3">Logout</a>
	    <h1 class="text-center">Administrator Dashboard</h1>
	    <p class="text-center">Developed by Suraj Prakash Ratna</p>
	  </div>     
	</div>
	
    <div class="container-fluid">
    	<div class="row justify-content-center">
    		<div class="col-lg-6 col-md-6 col-12 mt-5">
    		<h4 class="text-center text-capitalize mt-0 mb-5">Upload CSV file in database</h4>
               <div class="card shadow">
               	<div class="card-body">
               		<form action="" method="POST" enctype="multipart/form-data">
               			<div class="form-group">
               				<div class="custom-file">
							    <input type="file" class="custom-file-input" id="csv_file" name="csv_file" required accept=".csv" >
							    <label class="custom-file-label" for="csv_file">Choose file</label>
							</div>
               			</div>
               			<div class="form-group">
               				<input type="submit" name="import_csv" id="import_csv_btn" class="btn btn-outline-primary" value="Upload">
               			</div>
               		</form><div id="imported_csv_data"></div>
               	</div>
               </div>
    		</div>
    	</div>
    </div>
    <script>
	// Add the following code if you want the name of the file appear on select
	$(".custom-file-input").on("change", function() {
	  var fileName = $(this).val().split("\\").pop();
	  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
	});
	</script>
	<script>
$(document).ready(function(){

 load_data();

 function load_data()
 {
  $.ajax({
   url:"<?php echo base_url(); ?>csv_import/load_data",
   method:"POST",
   success:function(data)
   {
    $('#imported_csv_data').html(data);
   }
  })
 }

 $('#import_csv').on('submit', function(event){
  event.preventDefault();
  $.ajax({
   url:"<?php echo base_url(); ?>csv_import/import",
   method:"POST",
   data:new FormData(this),
   contentType:false,
   cache:false,
   processData:false,
   beforeSend:function(){
    $('#import_csv_btn').html('Importing...');
   },
   success:function(data)
   {
    $('#import_csv')[0].reset();
    $('#import_csv_btn').attr('disabled', false);
    $('#import_csv_btn').html('Import Done');
    load_data();
   }
  })
 });
 
});
</script>
</body>
</html>