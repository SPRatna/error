<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin | Dashboard</title>
	<link rel="stylesheet" href="<?php echo base_url();?>public/suraj/bootstrap.min.css">
	<script type="text/javascript" src="<?php echo base_url();?>public/suraj/jquery.min.css"></script>
	<script type="text/javascript" src="<?php echo base_url();?>public/suraj/popper.min.css"></script>	
	<script type="text/javascript" src="<?php echo base_url();?>public/suraj/bootstrap.min.css"></script>
</head>
<body>
	<div class="container-fluid">
	  <div class="jumbotron">
	  	<a href="<?php echo base_url().'admin/login/logout';?>" class="btn btn-outline-danger float-right mt-n3">Logout</a>
        <a href="<?php echo base_url().'index.php/admin/csv/index';?>" class="btn btn-outline-primary float-right mt-n3">Upload CSV</a>
	    <h1 class="text-center">Administrator Dashboard</h1>
	    <p class="text-center">Developed by Suraj Prakash Ratna</p>
	  </div>     
	</div>
    <div class="container box">
        <br />

        <form method="post" id="import_csv" enctype="multipart/form-data">
            <div class="form-group">
                <label>Select CSV File</label>
                <input type="file" name="csv_file" id="csv_file" required accept=".csv" />
            </div>
            <br />
            <button type="submit" name="import_csv" class="btn btn-info" id="import_csv_btn">Import CSV</button>
        </form>
        <br />
        <div id="imported_csv_data"></div>
    </div>
    <script>
$(document).ready(function(){

    load_data();

    function load_data()
    {
        $.ajax({
            url:"<?php echo base_url(); ?>csv_import/load_data",
            method:"POST",
            success:function(data)
            {
                $('#imported_csv_data').html(data);
            }
        })
    }

    $('#import_csv').on('submit', function(event){
        event.preventDefault();
        $.ajax({
            url:"<?php echo base_url(); ?>csv_import/import",
            method:"POST",
            data:new FormData(this),
            contentType:false,
            cache:false,
            processData:false,
            beforeSend:function(){
                $('#import_csv_btn').html('Importing...');
            },
            success:function(data)
            {
                $('#import_csv')[0].reset();
                $('#import_csv_btn').attr('disabled', false);
                $('#import_csv_btn').html('Import Done');
                load_data();
            }
        })
    });
    
});
</script>
</body>
</html>